package models.data;

public class ClassName {
    public static final String ECONOMY = "ECONOMY";
    public static final String BUSINESS = "BUSINESS";
    public static final String FIRSTCLASS = "FIRSTCLASS";
}
