//package controller;
//
//import models.dataStructure.People;
//import badViews.PersonView;
//
//public class PersonController
//{
//    public static People people;
//    private PersonView personView;
//
//    public PersonController()
//    {
//        people = new People();
//        personView = new PersonView();
//        personView.signUp();
//        people.addPerson(personView.getFirstName(), personView.getLastName(), personView.getEmail(),
//                personView.getUsername(), personView.getPassword(), personView.getId(), personView.getPhoneNo(),
//                personView.getRole(), personView.getAirline(), personView.getAgency(), personView.getNationality(),
//                personView.getPoint(), personView.getProfilePic());
//    }
//}
